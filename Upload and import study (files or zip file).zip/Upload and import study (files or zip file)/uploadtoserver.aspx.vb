﻿Imports System.IO
Imports System.Net
Imports Ionic.Zip

Public Class uploadtoserver
	Inherits System.Web.UI.Page

	Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

	End Sub

	Protected Sub UploadMultipleImages(sender As Object, e As EventArgs) Handles btnUploadImages.Click
		dim ext as String

		If fuImages.HasFiles = False Then
			lblResult.Text = "No files selected for import."
			Exit Sub
		End If

		Dim exists As Boolean = System.IO.Directory.Exists(Server.MapPath("~/upload_temp/"))
		If Not exists Then System.IO.Directory.CreateDirectory(Server.MapPath("~/upload_temp/"))

		For Each postedFile As HttpPostedFile In fuImages.PostedFiles
			Dim fileName As String = Path.GetFileName(postedFile.FileName)
			postedFile.SaveAs(Server.MapPath("~/upload_temp/") & fileName)
			ext = Path.GetExtension(Server.MapPath("~/upload_temp/") & fileName)
			If ext.ToLower().Contains("zip") = True Then
				Using zip As ZipFile = ZipFile.Read(Server.MapPath("~/upload_temp/") & fileName)
					zip.ExtractAll(Server.MapPath("~/upload_temp/"), ExtractExistingFileAction.OverwriteSilently)
				End Using
				File.Delete(Server.MapPath("~/upload_temp/") & fileName)
			end if
		Next

		lblResult.Text = UPLOAD_DIR_FILES_TO_PACS(Server.MapPath("~/upload_temp/"))

		'clear the directory
		Dim di As System.IO.DirectoryInfo = New DirectoryInfo(Server.MapPath("~/upload_temp/"))
		For Each file As FileInfo In di.GetFiles()
			file.Delete()
		Next

		For Each dir As DirectoryInfo In di.GetDirectories()
			dir.Delete(True)
		Next
	End Sub


	Public Function UPLOAD_DIR_FILES_TO_PACS(path As String) As String
		dim response As String = ""
		Dim success As Int32 = 0
		Dim failed As Int32 = 0
		Dim already As Int32 = 0
		Dim filecount As Int32 = 0
		Dim starttime as String = "Start Time: " & datetime.Now.ToString("dd/MM/yyyy hh:mm:ss.fff tt") & "<br />"

		For Each fileName As String In Directory.GetFiles(path, "*.*", searchOption.AllDirectories)
			filecount = filecount + 1
			response = UPLOAD_FILE_TO_PACS(fileName)
			If response.Contains("Success") Then
				success = success + 1
			ElseIf response.Contains("Already") Then
				already = already + 1
			Else
				failed = failed + 1
			End If
		Next

		response = starttime & "Total Files: " & filecount & "<br />Imported: " & success & "<br /> Failed: " & failed & "<br /> Already Imported: " & already & "<br /> End Time: " & datetime.Now.ToString("dd/MM/yyyy hh:mm:ss.fff tt")
		Return response
	End Function

	Public Function UPLOAD_FILE_TO_PACS(filepath As String) As String
		Dim request As WebRequest = WebRequest.Create("http://localhost:8042/instances ")
		request.Method = "POST"
		Dim byteArray As Byte() = File.ReadAllBytes(filepath)
		request.ContentType = "application/x-www-form-urlencoded"
		request.Credentials = New NetworkCredential("ethos", "ethos567")
		request.PreAuthenticate = true
		request.ContentLength = byteArray.Length
		Dim dataStream As Stream = request.GetRequestStream()
		dataStream.Write(byteArray, 0, byteArray.Length)
		dataStream.Close()
		Dim response As WebResponse = request.GetResponse()
		Console.WriteLine((CType(response, HttpWebResponse)).StatusDescription)
		dataStream = response.GetResponseStream()
		Dim reader As StreamReader = New StreamReader(dataStream)
		Dim responseFromServer As String = reader.ReadToEnd()
		reader.Close()
		dataStream.Close()
		response.Close()
		Return responseFromServer
	End Function

End Class